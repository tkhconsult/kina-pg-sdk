<?php
include('vendor/autoload.php');

use Symfony\Component\Dotenv\Dotenv;
use TkhConsult\KinaBankGateway\KinaBankGateway;

$dotenv = new Dotenv(1);
$dotenv->load(__DIR__.'/.env');

$kinaBankGateway = new KinaBankGateway();
$certDir = './key/';
$kinaBankGateway
    ->configureFromEnv($certDir)
   ->setGatewayUrl('https://test-ipg.kinabank.com.pg/cgi-bin/cgi_link')  // for testing
;

$backRefUrl = trim(getenv('KINA_BANK_MERCHANT_URL'), '/') . '/after-payment.php';

/** @var KinaBankGateway $kinaBankGateway */

?>
<!DOCTYPE html>
<html lang="en">
   <head>
       <?php include('includes/meta.php');?>
   </head>
   <!-- body -->
   <body class="main-layout">
      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#" /></div>
      </div>
      <!-- end loader -->
      <!-- header -->
      <header>
         <!-- header inner -->
         <div  class="head_top">
            <div class="header">
               <div class="container">
                  <div class="row">
                     <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                        <div class="full">
                           <div class="center-desk">
                              <div class="logo">
                                 <a href=""  class="titlepage">
                                     <h2 style="color: #0FE596">SDK Demo</h2>
                                 </a>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                        <nav class="navigation navbar navbar-expand-md navbar-dark ">
                           <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                           <span class="navbar-toggler-icon"></span>
                           </button>
                           <div class="collapse navbar-collapse" id="navbarsExample04">
                              <ul class="navbar-nav mr-auto">
                                 <li class="nav-item">
                                    <a class="nav-link" href=""> Home  </a>
                                 </li>
                                 <li class="nav-item">
                                    <a class="nav-link" href="#about">About</a>
                                 </li>
                                 <li class="nav-item">
                                    <a class="nav-link" href="#contact">Contact us</a>
                                 </li>
                              </ul>
                              <div class="sign_btn"><a href="#">Sign in</a></div>
                           </div>
                        </nav>
                     </div>
                  </div>
               </div>
            </div>
            <!-- end header inner -->
            <!-- end header -->
            <!-- banner -->
            <section class="banner_main">
               <div class="container-fluid">
                  <div class="row d_flex">
                     <div class="col-md-5">
                        <div class="text-bg">
                           <h1>Computer and <br>laptop shop</h1>
                           <strong>8 Core CPU Notebook</strong>
                           <span>PGK 1</span>
                           <?php $kinaBankGateway
    ->requestAuthorization($orderId = 1, $amount = '0.10', $backRefUrl, $currency = "PGK", $description = "8 Core CPU Notebook", $clientEmail = "customer@yopmail.com", $language = 'en');
?>
                        </div>
                     </div>
                     <div class="col-md-7 padding_right1">
                        <div class="text-img">
                           <figure><img src="images/top_img.png" alt="#"/></figure>
                           <h3>01</h3>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
         </div>
      </header>
      <!-- end banner -->
      <!-- about -->
      <div id="about" class="about">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="titlepage">
                     <h2>About SDK Demo</h2>
                      <span>This PHP website is integrated to Kinabank Payment Gateway using SDK @ <a href="https://github.com/tkhconsult/kina-pg-sdk" style="color: white">https://github.com/tkhconsult/kina-pg-sdk</a></a></span>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-8 offset-md-2 ">
                  <div class="about_box ">
                     <figure><img src="images/about_img.png" alt="#"/></figure>
                     <a class="read_more" href="https://github.com/tkhconsult/kina-pg-sdk">Read more</a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- about -->
      <?php include('includes/footer.php');?>
   </body>
</html>