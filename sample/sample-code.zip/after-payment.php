<?php

include('vendor/autoload.php');

use Symfony\Component\Dotenv\Dotenv;
use TkhConsult\KinaBankGateway\KinaBankGateway;
use TkhConsult\KinaBankGateway\KinaBank\Exception;
use TkhConsult\KinaBankGateway\KinaBank\Response;

$dotenv = new Dotenv(1);
$dotenv->load(__DIR__.'/.env');

$kinaBankGateway = new KinaBankGateway();
$certDir = './key/';
$kinaBankGateway
    ->configureFromEnv($certDir)
    ->setGatewayUrl('https://test-ipg.kinabank.com.pg/cgi-bin/cgi_link') // for testing
;

/** @var KinaBankGateway $kinaBankGateway */
$bankResponse = $kinaBankGateway->getResponseObject($_POST);
$error = '';
if (!$bankResponse->isValid()) {
    $error = 'Invalid bank Auth response ' . print_r($bankResponse->getErrors(), true);
}

switch ($bankResponse::TRX_TYPE) {
    case KinaBankGateway::TRX_TYPE_AUTHORIZATION:
        $orderId        = KinaBankGateway::deNormalizeOrderId($bankResponse->{Response::ORDER});
        $amount         = $bankResponse->{Response::AMOUNT};
        $bankOrderCode  = $bankResponse->{Response::ORDER};
        $rrn            = $bankResponse->{Response::RRN};
        $intRef         = $bankResponse->{Response::INT_REF};

        #
        # You must save $rrn and $intRef from the response here for reversal requests
        #
        # echo '<pre>';
        # print_r([$bankResponse, $orderId]);
        break;

    default:
        $error = 'Unknown bank response transaction type';
}

?>
<!DOCTYPE html>
<html lang="en">
   <head>
       <?php include('includes/meta.php');?>
   </head>
   <!-- body -->
   <body class="main-layout">
      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#" /></div>
      </div>
      <!-- end loader -->
      <!-- header -->
      <header>
         <!-- header inner -->
         <div  class="head_top">
            <div class="header">
               <div class="container">
                  <div class="row">
                     <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                        <div class="full">
                           <div class="center-desk">
                              <div class="logo">
                                  <a href="index.php"  class="titlepage">
                                      <h2 style="color: #0FE596">SDK Demo</h2>
                                  </a>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                        <nav class="navigation navbar navbar-expand-md navbar-dark ">
                           <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                           <span class="navbar-toggler-icon"></span>
                           </button>
                           <div class="collapse navbar-collapse" id="navbarsExample04">
                              <ul class="navbar-nav mr-auto">
                                 <li class="nav-item">
                                    <a class="nav-link" href="index.php"> Home  </a>
                                 </li>
                                 <li class="nav-item">
                                    <a class="nav-link" href="#about">About</a>
                                 </li>
                                 <li class="nav-item">
                                    <a class="nav-link" href="#contact">Contact us</a>
                                 </li>
                              </ul>
                              <div class="sign_btn"><a href="#">Sign in</a></div>
                           </div>
                        </nav>
                     </div>
                  </div>
               </div>
            </div>
            <!-- end header inner -->
            <!-- end header -->
         </div>
      </header>
      <!-- end banner -->
      <!-- about -->
      <div id="about" class="about" style="margin: 0">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="titlepage" style="margin-top: 90px">
                    <?php if(!empty($error)) {?>
                        <div class="alert alert-danger">Error: <?php echo $error; ?></div>
                    <?php } else { ?>
                     <h2>Receipt</h2>
                     <?php } ?>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-8 offset-md-2 ">
                  <div class="about_box ">
                     <figure><img src="images/about_img.png" alt="#"/></figure>

                        <div class="table-responsive">
                            <table class="table  table-bordered table-dark">
                            <tbody>
                                <?php foreach($_POST as $key => $val) {?>
                                    <tr class="text-left">
                                        <th scope="row"><?php echo $key; ?></th>
                                        <td><?php echo $val; ?></td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                            </table>
                        </div>

                     <a class="read_more" href="index.php" style="margin-top: 30px">Back to Home</a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- about -->
      <?php include('includes/footer.php');?>
   </body>
</html>

