<?php

include('vendor/autoload.php');

use Symfony\Component\Dotenv\Dotenv;
use TkhConsult\KinaBankGateway\KinaBankGateway;
use TkhConsult\KinaBankGateway\KinaBank\Exception;
use TkhConsult\KinaBankGateway\KinaBank\Response;

$dotenv = new Dotenv(1);
$dotenv->load(__DIR__.'/.env');

$kinaBankGateway = new KinaBankGateway();
$certDir = './key/';
$kinaBankGateway
    ->configureFromEnv($certDir)
    ->setGatewayUrl('https://devegateway.kinabank.com.pg/cgi-bin/cgi_link') // for testing
;

/** @var KinaBankGateway $kinaBankGateway */
$bankResponse = $kinaBankGateway->getResponseObject($_POST);

if (!$bankResponse->isValid()) {
    echo 'Invalid bank Auth response';
    exit;
}

switch ($bankResponse::TRX_TYPE) {
    case KinaBankGateway::TRX_TYPE_AUTHORIZATION:
        $orderId        = KinaBankGateway::deNormalizeOrderId($bankResponse->{Response::ORDER});
        $amount         = $bankResponse->{Response::AMOUNT};
        $bankOrderCode  = $bankResponse->{Response::ORDER};
        $rrn            = $bankResponse->{Response::RRN};
        $intRef         = $bankResponse->{Response::INT_REF};

        #
        # You must save $rrn and $intRef from the response here for reversal requests
        #
        echo '<pre>';
        print_r([$bankResponse, $orderId]);

        # Funds locked on bank side - transfer the product/service to the customer and request completion
        $kinaBankGateway->requestCompletion($orderId, $amount, $rrn, $intRef, $currency = "PGK");
        break;

    default:
        throw new Exception('Unknown bank response transaction type');
}